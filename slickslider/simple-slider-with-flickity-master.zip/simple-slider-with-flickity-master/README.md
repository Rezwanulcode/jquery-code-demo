# Simple Carousel/Slider with Flickity
This is the simple code for using simple plugin provided by flickity. By htis we can easily make a carousel/Slider in our websites.

# Just include these CDN files in your file and you are good to go!
```
<!-- CSS -->
<link rel="stylesheet" href="https://unpkg.com/flickity@2/dist/flickity.min.css">

<!-- JavaScript -->
<script src="https://unpkg.com/flickity@2/dist/flickity.pkgd.min.js"></script>

```
